"""Miscellaneous mathematical operators."""

from janitor.accessors.data_description import DataDescription  # noqa: F401
