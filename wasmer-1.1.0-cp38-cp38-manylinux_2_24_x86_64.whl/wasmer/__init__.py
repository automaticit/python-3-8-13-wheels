from .wasmer import *

__doc__ = wasmer.__doc__
