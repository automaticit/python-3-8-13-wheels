from SALib.util import ProblemSpec

__version__ = "1.4.7"

__all__ = ["ProblemSpec"]
