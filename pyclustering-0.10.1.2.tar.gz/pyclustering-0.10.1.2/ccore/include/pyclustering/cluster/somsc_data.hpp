/*!

@authors Andrei Novikov (pyclustering@yandex.ru)
@date 2014-2020
@copyright BSD-3-Clause

*/


#pragma once


#include <pyclustering/cluster/cluster_data.hpp>


namespace pyclustering {

namespace clst {


using somsc_data = cluster_data;


}

}