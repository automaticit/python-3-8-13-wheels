"""!

@brief Collection of examples devoted to clustering algorithms and methods.

@authors Andrei Novikov (pyclustering@yandex.ru)
@date 2014-2020
@copyright BSD-3-Clause

"""