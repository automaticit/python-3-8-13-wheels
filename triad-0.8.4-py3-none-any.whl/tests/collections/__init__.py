from tests.utils.convert_examples import BaseClass, SubClass, Class2
