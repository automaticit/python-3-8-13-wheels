PRE_RESOLVE = "pre-resolve"

PRE_HANDLE = "pre-handle"

CONFIG = "config"
