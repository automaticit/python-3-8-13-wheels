from .default_resolver import DefaultResolver
