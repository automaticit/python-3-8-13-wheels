# flake8: noqa
from fugue.extensions.outputter.convert import (
    _to_outputter,
    outputter,
    parse_outputter,
    register_outputter,
)
from fugue.extensions.outputter.outputter import Outputter
