#!/usr/bin/env python3


def main() -> None:
  from modelbit.cli import cmdline
  cmdline.processArgs()


if __name__ == '__main__':
  main()
