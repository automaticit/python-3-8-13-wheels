from demon.alg.Demon import main

main()

