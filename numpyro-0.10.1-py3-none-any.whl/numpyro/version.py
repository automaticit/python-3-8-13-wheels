# Copyright Contributors to the Pyro project.
# SPDX-License-Identifier: Apache-2.0

__version__ = "0.10.1"
