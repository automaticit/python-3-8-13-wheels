from dynetx.readwrite.edgelist import *
from dynetx.readwrite.json_graph import *