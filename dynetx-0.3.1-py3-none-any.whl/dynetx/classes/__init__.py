from .dyndigraph import DynDiGraph
from .dyngraph import DynGraph
from .function import *