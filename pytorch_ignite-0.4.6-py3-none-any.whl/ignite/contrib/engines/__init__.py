from ignite.contrib.engines.tbptt import Tbptt_Events, create_supervised_tbptt_trainer
