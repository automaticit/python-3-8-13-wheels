# For compatibility
from ignite.utils import apply_to_tensor, apply_to_type, convert_tensor, to_onehot

__all__ = ["apply_to_tensor", "apply_to_type", "convert_tensor", "to_onehot"]
