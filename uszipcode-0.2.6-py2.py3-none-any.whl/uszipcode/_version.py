__version__ = "0.2.6"

if __name__ == "__main__":  # pragma: no cover
    print(__version__)
