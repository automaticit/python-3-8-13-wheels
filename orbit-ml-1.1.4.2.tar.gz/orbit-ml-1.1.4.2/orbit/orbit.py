"""Top level Orbit class"""


class Orbit:
    pass
