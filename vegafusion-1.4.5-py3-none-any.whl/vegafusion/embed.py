# VegaFusion
# Copyright (C) 2022, Jon Mease
#
# This program is distributed under multiple licenses.
# Please consult the license documentation provided alongside
# this program the details of the active license.
try:
    from vegafusion_embed import *
except ImportError:
    raise ImportError("Please install the vegafusion-python-embed package")
