# Snowpark Container Service GPU instance type and corresponding GPU counts.
INSTANCE_TYPE_TO_GPU_COUNT = {"GPU_3": 1, "GPU_5": 1, "GPU_7": 4, "GPU_10": 8}
