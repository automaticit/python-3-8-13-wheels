# Prophet: Automatic Forecasting Procedure

As of v1.0, Prophet has moved to use the name "[prophet](https://pypi.org/project/prophet/)" on PyPI and not the original name of "fbprophet". This package is now just a shim for using the prophet package. Please change references in your code to use "prophet" instead of "fbprophet".

See https://facebook.github.io/prophet/ for full documentation.
