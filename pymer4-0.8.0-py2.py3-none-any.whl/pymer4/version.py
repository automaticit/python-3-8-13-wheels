"""Specifies current version of pymer4 to be used by setup.py and __init__.py
"""

__version__ = "0.8.0"
