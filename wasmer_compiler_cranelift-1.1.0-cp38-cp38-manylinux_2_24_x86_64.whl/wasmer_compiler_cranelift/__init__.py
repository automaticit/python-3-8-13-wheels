from .wasmer_compiler_cranelift import *

__doc__ = wasmer_compiler_cranelift.__doc__
