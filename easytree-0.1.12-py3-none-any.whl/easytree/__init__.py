from easytree.tree import (
    new,
    Node,
    serialize,
    load,
    loads,
    dump,
    dumps,
    frozen,
    freeze,
    unfreeze,
    sealed,
    seal,
    unseal,
)

# export Node as Tree
Tree = Node
