__with_libyaml__ = False

from .main import *  # NOQA

version_info = (0, 16, 7)
__version__ = "0.16.7"
