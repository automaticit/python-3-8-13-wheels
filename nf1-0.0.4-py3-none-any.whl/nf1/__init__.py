from .NF1_class import NF1
from .F1_communities import F1_communities as NF1main

