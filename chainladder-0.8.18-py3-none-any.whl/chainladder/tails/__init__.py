""" tails should store all tail methodologies
"""
from chainladder.tails.base import TailBase  # noqa (API import)
from chainladder.tails.constant import TailConstant  # noqa (API import)
from chainladder.tails.curve import TailCurve  # noqa (API import)
from chainladder.tails.bondy import TailBondy  # noqa (API import)
from chainladder.tails.clark import TailClark  # noqa (API import)
