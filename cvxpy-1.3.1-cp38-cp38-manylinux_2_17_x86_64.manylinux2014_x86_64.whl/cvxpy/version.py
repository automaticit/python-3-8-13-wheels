
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.3.1'
version = '1.3.1'
full_version = '1.3.1'
git_revision = '2a135d2'
commit_count = '0'
release = True
if not release:
    version = full_version
