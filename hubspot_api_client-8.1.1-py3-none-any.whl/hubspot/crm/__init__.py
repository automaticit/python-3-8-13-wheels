from .object_type import ObjectType
from .association_type import AssociationType
