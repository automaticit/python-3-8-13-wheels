from .client import Client


class HubSpot(Client):
    pass
