# -*- coding: utf-8 -*-

"""Top-level package for fastdiff."""

from .compare import compare

__author__ = """Syrus Akbary"""
__email__ = 'me@syrusakbary.com'
__version__ = '0.1.0'

__all__ = ["compare"]
